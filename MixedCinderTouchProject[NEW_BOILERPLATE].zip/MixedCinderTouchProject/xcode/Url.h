// Url.h -- Obj-C

#pragma once
#import <CoreFoundation/CoreFoundation.h>

@interface Url : NSObject {
}   

+ ( void ) open: (NSString*) url;

@end