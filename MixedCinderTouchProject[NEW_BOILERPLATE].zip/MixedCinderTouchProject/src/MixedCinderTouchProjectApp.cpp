// Stéphane Adam Garnier - 2012

// include Cinder lib(s)
#include "cinder/app/AppCocoaTouch.h"
#include "cinder/app/Renderer.h"
#include "cinder/Surface.h"
#include "cinder/gl/Texture.h"
#include "cinder/Camera.h"
#include "cinder/thread.h"

// include standard lib(s)
#include <string>

// include 3rd party lib(s)

// include custom lib(s) 

using namespace ci;
using namespace ci::app;


// CINDER APP MAIN CLASS

class MixedCinderTouchProjectApp : public AppCocoaTouch {
  public:
	virtual void	setup();
	virtual void	update();
	virtual void	draw();
    virtual void    shutdown();
    
};

/* // //////////////////////////////////////////////////// APP MAIN FUNCTIONS //////////////////////////////////////////////////// // */
void MixedCinderTouchProjectApp::shutdown(){
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::shutdown() ] " << std::endl;
}


void MixedCinderTouchProjectApp::setup()
{
    
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::setup() ] " << std::endl;
    
}

void MixedCinderTouchProjectApp::update()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::update() ] " << std::endl;
    
    
}

void MixedCinderTouchProjectApp::draw()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::draw() ] " << std::endl;
    
	gl::clear( Color( 0.2f, 0.2f, 0.3f ) );
	
}

CINDER_APP_COCOA_TOUCH( MixedCinderTouchProjectApp, RendererGl )
