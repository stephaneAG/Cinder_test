// Receiver.cpp - C++ implementation file
// Stéphane Adam Garnier - 2012

#include "Receiver.h" // include the C++ header file


 Receiver::Receiver(){
     _intBufferReference = NULL;
     _intBufferPointer = NULL;
     //_charBufferReference = NULL;
     _bufferUpdateBool = 0;
     _bufferUpdateBoolPointer = NULL;
     //_callbackFunction = NULL;
     _callbackFunctionPointer = NULL;
 }


void Receiver::setReceiverIntBufferAndBufferUpdateBool( int &theIntBuffer, bool &theBufferUpdateBool ){
    std::cout << " [ Receiver::setReceiverIntBufferAndBufferUpdateBool() ] " << std::endl;
    _intBufferPointer = &theIntBuffer;
    _bufferUpdateBoolPointer = &theBufferUpdateBool;
}

void Receiver::dummyWriteIntBufferAndBufferUpdateBool(){
    std::cout << " [ Receiver::dummyWriteIntBufferAndBufferUpdateBool() ] " << std::endl;
    *_intBufferPointer = 45454545; // update the value pointed by the pointer held by the 'Receiver' class private var
    *_bufferUpdateBoolPointer = 1; // update the bool to indicate new data ( can be used in the 'main' loop , example in cinder maybe in the 'update' fcn (..) )
}

void Receiver::invokeFunctionPassedUsingReference( callback_function &theCallbackFunction  ){
    std::cout << " [ Receiver::invokeFunctionPassedUsingReference() ] " << std::endl;
    theCallbackFunction(); // invoke the function passed by reference
}

void Receiver::setCallbackFunctionPointerByCallbackFunctionReference( callback_function &theCallbackFunction ){ // hold the passed function reference as a pointer var
    std::cout << " [ Receiver::setCallbackFunctionPointerByCallbackFunctionReference() ] " << std::endl;
    _callbackFunctionPointer = theCallbackFunction; // assign the function passed as reference to the class 'callbackFunctionPointer'
}

void Receiver::invokeCallbackFunctionFromHeldCallbackFunctionPointer(){ // invoke function from held pointer var using  explicit or implicit 'dereference'
    std::cout << " [ Receiver::invokeCallbackFunctionFromHeldCallbackFunctionPointer() ] " << std::endl;
    // manner 1: using 'explicit dereference'
    //(*_callbackFunctionPointer)(); // works
    
    // manner 2: using 'implicit dereference'
    _callbackFunctionPointer();
}