// Receiver.h - C++ header file

#ifndef Receiver_h
#define Receiver_h

#pragma once
#include <string>
#include <iostream>

class Receiver{   
    //typedef void (&callback_function)(void);
    typedef void (&callback_function)(void); // for the fcn passed as reference
    typedef void (*callback_function_ptr)(); // for the fcn passed as pointer
	
public:
    Receiver();
    //void setReceiverCharBufferAndBufferUpdateBool( char &theCharBuffer, bool &theBufferUpdateBool ); // not working
    void setReceiverIntBufferAndBufferUpdateBool( int &theIntBuffer, bool &theBufferUpdateBool ); // not working
    
    //void setReceiverIntBufferAndBufferUpdateBool( int *theIntBuffer, bool *theBufferUpdateBool );
    void dummyWriteIntBufferAndBufferUpdateBool();
    
    void setDummyValuesForIntBufferAndUpdateBool(int &theIntBuffer, bool &theBufferUpdateBool ); // works
    void invokeFunctionPassedUsingReference( callback_function &theCallbackFunction ); // works
    void setCallbackFunctionPointerByCallbackFunctionReference( callback_function &theCallbackFunction ); // works > nb: by now, invoke the passed fcn after setting its pointer [ from it ]
    void invokeCallbackFunctionFromHeldCallbackFunctionPointer(); // works 
    
    //void invokeFunctionPassedUnsingPointer( callback_function_ptr *theCallbackFunction ); // not working
    
    //void setIntBufferAndUpdateBool(int &theIntBuffer, bool &theBufferUpdateBool ); // seems to work ( hold a value being at the same adress (..) )
    //void writeValuesForIntBufferAndUpdateBool(); // not working ! > can't seem to be able to write to original variables using held references (..)
    
    //void setReceiverCallbackFunction( callback_function &theCallbackFunction);
    
    //void dummyWriteToIntBufferRef(); // not working
    //void dummyInvokeCallbackFunction();
    
private:
    int _intBufferReference;
    int *_intBufferPointer;
    //char &_charBufferReference;
    
    //callback_function _callbackFunction;
    
    bool _bufferUpdateBool;
    bool *_bufferUpdateBoolPointer;
    
    callback_function_ptr _callbackFunctionPointer;
};

#endif
