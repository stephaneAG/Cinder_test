// Receiver.cpp - C++ implementation file

#include "Receiver.h" // include the C++ header file


 Receiver::Receiver(){
     _intBufferReference = NULL;
     _intBufferPointer = NULL;
     //_charBufferReference = NULL;
     _bufferUpdateBool = 0;
     _bufferUpdateBoolPointer = NULL;
     //_callbackFunction = NULL;
     _callbackFunctionPointer = NULL;
 }

//void Receiver::setReceiverCharBufferAndBufferUpdateBool(char &theCharBuffer, bool &theBufferUpdateBool ){
//    _charBufferReference = theCharBuffer;
//    _bufferUpdateBool = theBufferUpdateBool;
//}

//void Receiver::setReceiverIntBufferAndBufferUpdateBool( int &theIntBuffer, bool &theBufferUpdateBool ){
//    _intBufferReference = theIntBuffer;
//    _bufferUpdateBool = theBufferUpdateBool;
//}

void Receiver::setReceiverIntBufferAndBufferUpdateBool( int &theIntBuffer, bool &theBufferUpdateBool ){
    std::cout << " [ Receiver::setReceiverIntBufferAndBufferUpdateBool() ] " << std::endl;
    _intBufferPointer = &theIntBuffer;
    _bufferUpdateBoolPointer = &theBufferUpdateBool;
}

//void Receiver::setReceiverIntBufferAndBufferUpdateBool( int *theIntBuffer, bool *theBufferUpdateBool ){
//    std::cout << " [ Receiver::setReceiverIntBufferAndBufferUpdateBool() ] " << std::endl;
//    _intBufferPointer = theIntBuffer;
//    _bufferUpdateBoolPointer = theBufferUpdateBool;
//}

void Receiver::dummyWriteIntBufferAndBufferUpdateBool(){
    std::cout << " [ Receiver::dummyWriteIntBufferAndBufferUpdateBool() ] " << std::endl;
    *_intBufferPointer = 45454545; // update the value pointed by the pointer held by the 'Receiver' class private var
    *_bufferUpdateBoolPointer = 1; // update the bool to indicate new data ( can be used in the 'main' loop , example in cinder maybe in the 'update' fcn (..) )
}


//void Receiver::setReceiverCallbackFunction( callback_function &theCallbackFunction){
//    _callbackFunction = theCallbackFunction;
//}




//void Receiver::dummyWriteToIntBufferRef(){
//    _intBufferReference = 33; // change the value of the reference
//    _bufferUpdateBool = 1; // update the bool to notify that the buffer has been updated
//    std::cout << " [ Receiver ] Receiver has just updated the intBuffer and the bufferUpdate bool" << std::endl;
//    std::cout << " [ Receiver ] intBufferReference now equals: " << _intBufferReference << std::endl;
//    std::cout << " [ Receiver ] bufferUpdate now equals: " << _bufferUpdateBool << std::endl;
//}

//void Receiver::dummyInvokeCallbackFunction(){
//    _callbackFunction();
//}

//void Receiver::setIntBufferAndUpdateBool(int &theIntBuffer, bool &theBufferUpdateBool ){
//    _intBufferReference = theIntBuffer;
//    _bufferUpdateBool = theBufferUpdateBool;
//    
//    std::cout << " [ Receiver ] the reference to 'theIntBuffer' is located at adress: " << &theIntBuffer << " and contains value: " << theIntBuffer << std::endl;
//    std::cout << " [ Receiver ] the reference to 'theBufferUpdateBool' is located at adress: " << &theBufferUpdateBool << " and contains value: " << theBufferUpdateBool << std::endl;    
//}

//void Receiver::writeValuesForIntBufferAndUpdateBool(){
//    //int nValue = 123321123321;
//    //_intBufferReference = 123321; // does not work
//    //_intBufferReference -> nValue;
//    _bufferUpdateBool = 1;
//    
//    std::cout << " [ Receiver ] the reference to 'theIntBuffer' is located at adress: " << &_intBufferReference << " and contains value: " << _intBufferReference << std::endl;
//    std::cout << " [ Receiver ] the reference to 'theBufferUpdateBool' is located at adress: " << &_bufferUpdateBool << " and contains value: " << _bufferUpdateBool << std::endl;
//    
//}


void Receiver::setDummyValuesForIntBufferAndUpdateBool(int &theIntBuffer, bool &theBufferUpdateBool ){ // works
    theIntBuffer = 555;
    theBufferUpdateBool = 1;
    
    std::cout << " [ Receiver ] 'main' 'theIntBuffer' is located at adress: " << &theIntBuffer << std::endl;
    std::cout << " [ Receiver ] 'main' 'theBufferUpdateBool' is located at adress: " << &theBufferUpdateBool << std::endl;
    
}

void Receiver::invokeFunctionPassedUsingReference( callback_function &theCallbackFunction  ){
    std::cout << " [ Receiver::invokeFunctionPassedUsingReference() ] " << std::endl;
    theCallbackFunction(); // invoke the function passed by reference
}

void Receiver::setCallbackFunctionPointerByCallbackFunctionReference( callback_function &theCallbackFunction ){ // hold the passed function reference as a pointer var
    std::cout << " [ Receiver::setCallbackFunctionPointerByCallbackFunctionReference() ] " << std::endl;
    _callbackFunctionPointer = theCallbackFunction; // assign the function passed as reference to the class 'callbackFunctionPointer'
}

void Receiver::invokeCallbackFunctionFromHeldCallbackFunctionPointer(){ // invoke function from held pointer var using  explicit or implicit 'dereference'
    std::cout << " [ Receiver::invokeCallbackFunctionFromHeldCallbackFunctionPointer() ] " << std::endl;
    // manner 1: using 'explicit dereference'
    //(*_callbackFunctionPointer)(); // works
    
    // manner 2: using 'implicit dereference'
    _callbackFunctionPointer();
}

//void Receiver::invokeFunctionPassedUnsingPointer( callback_function_ptr *theCallbackFunction ){ // not working
//    (*theCallbackFunction)(); // invoke the function passed by pointer using 'explicit dereference'    
//}
