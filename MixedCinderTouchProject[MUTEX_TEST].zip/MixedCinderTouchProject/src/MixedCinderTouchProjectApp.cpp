// Stéphane Adam Garnier - 2012

// include Cinder lib(s)
#include "cinder/app/AppCocoaTouch.h"
#include "cinder/app/Renderer.h"
#include "cinder/Surface.h"
#include "cinder/gl/Texture.h"
#include "cinder/Camera.h"
#include "cinder/thread.h"


// include standard lib(s)
#include <string>
#include <cstring>
#include <iostream>

// include 3rd party lib(s)
#include "boost/asio.hpp"

// include custom lib(s) 

using namespace ci;
using namespace ci::app;

// for boost asio
using boost::asio::ip::tcp;

// CINDER APP MAIN CLASS

class MixedCinderTouchProjectApp : public AppCocoaTouch {
  public:
	virtual void	setup();
	virtual void	update();
	virtual void	draw();
    virtual void    shutdown();
    
};

// global scope variables //

/* // //////////////////////////////////////////////////// APP FCNS //////////////////////////////////////////////////// // */

boost::mutex mio; // 1
const int TIMES = 10;

void print(){
    boost::lock_guard<boost::mutex> lock(mio); // prevent multiple concurrent access from concurent threads 
    
    std::cout << "Thread printed this message using a mutex" << std::endl;
    
}

void runner(int times){
    
    for(int i=0; i < times; ++i){
        
        print();
        
        boost::this_thread::yield();
        
    }
    
}


/* // //////////////////////////////////////////////////// APP MAIN FUNCTIONS //////////////////////////////////////////////////// // */
void MixedCinderTouchProjectApp::shutdown(){
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::shutdown() ] " << std::endl;
}


void MixedCinderTouchProjectApp::setup()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::setup() ] " << std::endl;
    
    boost::thread t1(runner, TIMES); // call our function to work from within a thread
        
}

void MixedCinderTouchProjectApp::update()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::update() ] " << std::endl;
    boost::thread t1(runner, TIMES); // call our function to work from within a thread
    
    
}

void MixedCinderTouchProjectApp::draw()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::draw() ] " << std::endl;
    
	gl::clear( Color( 0.2f, 0.2f, 0.3f ) );
	
}

CINDER_APP_COCOA_TOUCH( MixedCinderTouchProjectApp, RendererGl )
