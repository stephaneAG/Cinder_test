// Stéphane Adam Garnier - 2012

// include Cinder lib(s)
#include "cinder/app/AppCocoaTouch.h"
#include "cinder/app/Renderer.h"
#include "cinder/Surface.h"
#include "cinder/gl/Texture.h"
#include "cinder/Camera.h"
#include "cinder/thread.h"

// include standard lib(s)
#include <string>

// include 3rd party lib(s)

// include custom lib(s) 
#include "Link.h" // include the custom class 'Link' (wich wraps up an Ojb-C fcn into a C++ one, allowing it to be able to be called from C++ and open an url in mobile safari )
//#include "Bridge.h"
#include "Receiver.h" // include the custom class "Receiver" ( handles vars & callback functions from class member references & pointers, as well as C++ -> ObjC | ObjC -> C++ 'callbacks' )

using namespace ci;
using namespace ci::app;

/* // TESTING 'BRIDGE' CUSTOM CLASS // */

// callback fcn test using the 'Bridge' custom class or other manners (..)
void bridgedCallbackFunction(){
    std::cout << "\n" << std::endl;
    std::cout << "Hello from a function passed as parameter and then used as callback !" << std::endl;
    std::cout << "\n" << std::endl;
}

// using fcn(s) inside 'main'
void bridgedCallbackFunctionTakingChar( const char* theChar ){
    std::cout << " ' bridgedCallbackFunctionTakingChar() ' called with chars: " << theChar << std::endl;
    std::cout << "\n" << std::endl;
}


void fcnCaller( void(*callbackFcn)(const char*) ){
    printf(" 'fcnCaller' invoking callback .. \n ");
    callbackFcn("up this is the place! "); // for the moment , just call the fcn bai
}


// same as above but this time using strings
void bridgedStrCallbackFcn(std::string theString){
    std::cout << " 'bridgedStrCallbackFcn(const std::string theString)' called with string: " << theString << std::endl;
    std::cout << "\n" << std::endl;
}

void strFcnCaller( void(*callbackFcn)(std::string) ){
    printf(" 'strFcnCaller' invoking callback .. \n ");
    callbackFcn("If this works i will have to guess why it works and why without a pointer on the std::string "); // for the moment , just call the fcn bai
}

// even more dynamic ?
void strFcnCallerWithParam( void(*callbackFcn)(std::string), std::string theStringToPass ){
    printf(" 'strFcnCaller' invoking callback .. \n ");
    callbackFcn( theStringToPass ); // invoke the callback function and pass it the provided parameter
}


// static for using with 'Bridge' ?
static void staticBridgedStrCallbackFcn(std::string theString){
    std::cout << " 'bridgedStrCallbackFcn(const std::string theString)' called with string: " << theString << std::endl;
    std::cout << "\n" << std::endl;
}


/* // TESTING STRUCTS // */

struct Loulou { // simple struct
    std::string sName;
    int nAge;
    float fNoseWidth;
};

// fcn to print informations about the 'struct' passed a argument
void printLoulouInfos( Loulou theLoulou){
    using namespace std;
    
    cout << "Loulou's Name: " << theLoulou.sName << endl;
    cout << "Loulou's Age: " << theLoulou.nAge << endl;
    cout << "Loulou's Nose width: " << theLoulou.fNoseWidth << endl;
    
}

// CINDER APP MAIN CLASS

class MixedCinderTouchProjectApp : public AppCocoaTouch {
  public:
	virtual void	setup();
	virtual void	update();
	virtual void	draw();
    virtual void    shutdown();
    
    virtual void    useThatThread();
    
};

// TESTING "RECEIVER" CLASS

void setDummyValuesForIntBufferAndUpdateBool(int &theIntBuffer, bool &theBufferUpdateBool ){
    theIntBuffer = 33;
    theBufferUpdateBool = 1;
}

Receiver recvr;

char charBuffer[] = "I love to dancing and to singing";
int intBuffer = 42;
bool bufferUpdate = 0;

int fakeCounter = 1;

void dummyFunction(){
    std::cout << "Hello World I am a dummy functin and my only purpose is to be invoked from my reference and ths from an external class instance .." << std::endl;
}


/* // //////////////////////////////////////////////////// APP MAIN FUNCTIONS //////////////////////////////////////////////////// // */
void MixedCinderTouchProjectApp::shutdown(){
    std::cout << "App is shutting donw right now ..." << std::endl;
}


void MixedCinderTouchProjectApp::useThatThread(){
    std::cout << "Using the thread from main app member function .." << std::endl;
    usleep(5000);
    std::cout << "Using the thread from main app member function .." << std::endl;
}

void MixedCinderTouchProjectApp::setup()
{
    
        std::cout << "[ main ] [ MixedCinderTouchProjectApp::setup() ] " << std::endl;
        
        // thread(s) setup(s)
        std::cout << "[ main ] [ MixedCinderTouchProjectApp::setup() ] >> setting up thread(s) .. " << std::endl;
        //std::thread thrd( &Receiver::logOnThatThread, this ); // > throw an error (..)
        std::thread thrd( &MixedCinderTouchProjectApp::useThatThread, this );
        thrd.join(); // seems to wait for the thread to finish (..)
        std::cout << "[ main ] [ MixedCinderTouchProjectApp::setup() ] >> thread(s) setup(s) finished. " << std::endl;
    
        //Link::openURL( "http://www.stephaneadamgarnier.com" ); // use our 'C++-wrapped' Obj-C fcn ( wich actually opens up a url in mobile safari )
        
        Loulou tef; // create a new 'Loulou struct'
        tef.sName = "Stéphane ADAM GARNIER";
        tef.nAge = 25;
        tef.fNoseWidth = 15.40f;
    
        Loulou tom; // create a new 'Loulou struct'
        tom.sName = "Thomas JOURDAN GASSIN";
        tom.nAge = 25;
        tom.fNoseWidth = 10.20f;
    
        // make use of our 'epintLoulouInfos' fcn
        printLoulouInfos( tef );
        printLoulouInfos( tom );
    
        /* // TESTING POINTERS // */
    
    int* nAgePtr = &tef.nAge; // 'pointer to' tef nAge value
    
    std::cout << "Pointer tests results: " << "tef.nAge adress =" << &tef.nAge << std::endl;
    std::cout << "Pointer tests results: " << "tef.nAge content =" << tef.nAge << std::endl;
    
    std::cout << "\n" << std::endl;
    
    std::cout << "Pointer tests results: " << "tef.nAge Ptr adress =" << nAgePtr << std::endl;
    std::cout << "Pointer tests results: " << "tef.nAge Ptr [dereferenced] content =" << *nAgePtr << std::endl;
    
    Loulou* loulouTefPtr = &tef; // 'pointer to' tef 'Loulou' struct
    std::cout << "Pointer test : 'tef' ( Loulou struct ) is located ( adress ) at: " << &tef << std::endl;
    std::cout << "Pointer test : 'tef' ( Loulou struct ) Ptr  is points to adress: " << loulouTefPtr << std::endl;
     // should print the Loulou's infos to the console, even when given a 'dereferenced pointer' as argument (..)
    std::cout << " Pointer test : 'tef' ( Loulou struct ) Ptr hold the following content: \n" << std::endl;
    printLoulouInfos( *loulouTefPtr );
    
    
    // testing the 'Bridge' custom class (..)
    //bridgedCallbackFunction(); // calling the mthd 'normally' > works
    //Bridge::setCallbackFunction( *bridgedCallbackFunction ); // hold the callback fcn in 'Bridge'
    fcnCaller( bridgedCallbackFunctionTakingChar );
    
    strFcnCaller( bridgedStrCallbackFcn );
    strFcnCallerWithParam(bridgedStrCallbackFcn, "I really hope it will work, but I guess it will ? ....");
    
    // using nearly same code 'packed-up' in the 'freshly-updated' custom 'Bridge' class
    //Bridge::setStrCallbackFunction( bridgedCallbackFunction , "If this works, I may be the happiest man on earth for a brief moment ;p");
    //Bridge::setCharCallbackFunction( bridgedCallbackFunctionTakingChar , "Do you like it ");
    
    // test the "Receiver" custom class
    
    //char charBuffer[] = "I love to dancing and to singing";
    //int intBuffer = 9876543210;
    //bool bufferUpdate = false;
    
    // > moved above in this file & outside of the 'setup' fcn cause of the fcns scope (..)
    
    
    //Receiver recvr;
    //recvr.setReceiverCharBufferAndBufferUpdateBool(charBuffer, bufferUpdate);
    recvr.setReceiverIntBufferAndBufferUpdateBool(intBuffer, bufferUpdate); // pass a buffer & a bool as refs to be able to update them from an external class member fcn (..)
    recvr.dummyWriteIntBufferAndBufferUpdateBool(); // works > write dummt value & update bool once
    recvr.invokeFunctionPassedUsingReference( dummyFunction ); // works > pass a fcn that will be invoked by reference from the 'Receiver' class instance member function
    recvr.setCallbackFunctionPointerByCallbackFunctionReference( dummyFunction ); // hold the passed function as a pointer in the 'Receiver' class
    recvr.invokeCallbackFunctionFromHeldCallbackFunctionPointer(); // invoke the fcn pointed by the pointer var hel by the 'Receiver' class
    // try a 'dummy write' on he above variables
    //recvr.dummyWriteToIntBufferRef();
    // try to  pass a fcn and later call it (..)
    //recvr.setReceiverCallbackFunction( dummyFunction );
    //recvr.dummyInvokeCallbackFunction();
    
    
    std::cout << " // Receiver Tests // " << std::endl;
    //test to see if the 'intBuffer' / 'bufferUpdate' were written ..
    if( bufferUpdate == true ){ // the 'bufferUpdate' bool has been updated by reference
        std::cout << " [ main ]  bufferUpdate is true" << std::endl;
        // get the data written to one of the buffers (> ex the 'intBuffer')
        std::cout << " [ main ]  intBuffer contains: " << intBuffer << std::endl;
        // set the 'bufferUpdate' bool back to false & 'reset' (set to NULL) the buffer content
        bufferUpdate = 0;
        intBuffer = NULL;
        
    } else {
            std::cout << "[ main ] bufferUpdate is false" << std::endl;
            std::cout << "[ main ] intBuffer contains: " << intBuffer << std::endl;
    }
    
    std::cout << " [ main ] the reference to 'theIntBuffer' is located at adress: " << &intBuffer << std::endl;
    std::cout << " [ main ] the reference to 'theBufferUpdateBool' is located at adress: " << &bufferUpdate << std::endl;
    
    
    // test the new function of 'Receiver' class: calling Objectie C function from C++ function wrappers
    recvr.logSomethingUsingObjC();
    recvr.initCallbackFromObjectiveC();
    
}

void MixedCinderTouchProjectApp::update()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::update() ] " << std::endl;
    
    if( fakeCounter == 1 ){
        //recvr.dummyWriteToIntBufferRef(); // not working
        //setDummyValuesForIntBufferAndUpdateBool(intBuffer, bufferUpdate); // works (fcn declared on 'main')
        //recvr.setDummyValuesForIntBufferAndUpdateBool(intBuffer, bufferUpdate); // works ( class member fcn)
        
        recvr.dummyWriteIntBufferAndBufferUpdateBool(); // write again once in the 'update' fcn, as it seems that the value by the external class during the setup 'vanishes' ?!
        
        std::cout << "[ main ] intBuffer contains: " << intBuffer << std::endl;
        std::cout << "[ main ] bufferUpdate contains: " << bufferUpdate << std::endl;
        
        //now in two steps > old, non-working fcns (..)
        //recvr.setIntBufferAndUpdateBool(intBuffer, bufferUpdate ); // step 1: pass references to be used later
        //recvr.writeValuesForIntBufferAndUpdateBool();
        
        fakeCounter++;
    } else if( fakeCounter == 2 ){
        
        std::cout << "[ main ] intBuffer contains: " << intBuffer << std::endl;
        std::cout << "[ main ] bufferUpdate contains: " << bufferUpdate << std::endl;
        
        std::cout << "[ main ] the fake counter now equals two > we won't do any further fake update" << std::endl;
        fakeCounter++;
    } else {
        // does nothing and print nothing
    }
    
     //test to see if the 'intBuffer' / 'bufferUpdate' were written ..
     if( bufferUpdate == 1 ){ // the 'bufferUpdate' bool has been updated by reference
     // get the data written to one of the buffers (> ex the 'intBuffer')
     std::cout << "[ main ] updated intBuffer contains: " << intBuffer << std::endl;
     // set the 'bufferUpdate' bool back to false & 'reset' (set to NULL) the buffer content
     bufferUpdate = 0;
     intBuffer = NULL;
     std::cout << "[ main ] intBuffer just set to NULL  and now equals: " << intBuffer << std::endl;
     }
     
    std::cout << "[ main ] intBuffer contains: " << intBuffer << std::endl;
    
}

void MixedCinderTouchProjectApp::draw()
{
    std::cout << "[ main ] [ MixedCinderTouchProjectApp::draw() ] " << std::endl;
    
	gl::clear( Color( 0.2f, 0.2f, 0.3f ) );
	
}

CINDER_APP_COCOA_TOUCH( MixedCinderTouchProjectApp, RendererGl )
