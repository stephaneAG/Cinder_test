#include "cinder/app/AppCocoaTouch.h"
#include "cinder/app/Renderer.h"
#include "cinder/Surface.h"
#include "cinder/gl/Texture.h"
#include "cinder/Camera.h"

// include string libray ?
#include <string>

// include the custom class 'Link' (wich wraps up an Ojb-C fcn into a C++ one, allowing it to be able to be called from C++ )
#include "Link.h"

using namespace ci;
using namespace ci::app;

/* // TESTING STRUCTS // */

struct Loulou { // simple struct
    std::string sName;
    int nAge;
    float fNoseWidth;
};

// fcn to print informations about the 'struct' passed a argument
void printLoulouInfos( Loulou theLoulou){
    using namespace std;
    
    cout << "Loulou's Name: " << theLoulou.sName << endl;
    cout << "Loulou's Age: " << theLoulou.nAge << endl;
    cout << "Loulou's Nose width: " << theLoulou.fNoseWidth << endl;
    
}

class MixedCinderTouchProjectApp : public AppCocoaTouch {
  public:
	virtual void	setup();
	virtual void	update();
	virtual void	draw();
    
};

void MixedCinderTouchProjectApp::setup()
{
        Link::openURL( "http://www.stephaneadamgarnier.com" ); // use our 'C++-wrapped' Obj-C fcn ( wich actually opens up a url in mobile safari )
        
        Loulou tef; // create a new 'Loulou struct'
        tef.sName = "Stéphane ADAM GARNIER";
        tef.nAge = 25;
        tef.fNoseWidth = 15.40f;
    
        Loulou tom; // create a new 'Loulou struct'
        tom.sName = "Thomas JOURDAN GASSIN";
        tom.nAge = 25;
        tom.fNoseWidth = 10.20f;
    
        // make use of our 'epintLoulouInfos' fcn
        printLoulouInfos( tef );
        printLoulouInfos( tom );
    
        /* // TESTING POINTERS // */
    
    int* nAgePtr = &tef.nAge; // 'pointer to' tef nAge value
    
    std::cout << "Pointer tests results: " << "tef.nAge adress =" << &tef.nAge << std::endl;
    std::cout << "Pointer tests results: " << "tef.nAge content =" << tef.nAge << std::endl;
    
    std::cout << "\n" << std::endl;
    
    std::cout << "Pointer tests results: " << "tef.nAge Ptr adress =" << nAgePtr << std::endl;
    std::cout << "Pointer tests results: " << "tef.nAge Ptr [dereferenced] content =" << *nAgePtr << std::endl;
    
    
    
}

void MixedCinderTouchProjectApp::update()
{

}

void MixedCinderTouchProjectApp::draw()
{
	gl::clear( Color( 0.2f, 0.2f, 0.3f ) );
	
}

CINDER_APP_COCOA_TOUCH( MixedCinderTouchProjectApp, RendererGl )
