// Link.h - C++

#pragma once
#include <string>

class Link{
 public:
	static void openURL( const std::string &url);
};